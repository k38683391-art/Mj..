package com.example.translatorkeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        root.addView(TextView(this).apply {
            textSize = 18f
            text = "ধাপ ১: নিচের বাটনে চেপে \"অনুবাদ কিবোর্ড\" চালু করুন।\n" +
                "ধাপ ২: যেকোনো চ্যাটে লিখুন, তারপর কিবোর্ড বদলে এই কিবোর্ডে এসে ভাষা বেছে \"অনুবাদ\" চাপুন।"
        })
        root.addView(Button(this).apply {
            text = "১. কিবোর্ড চালু করুন"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "২. কিবোর্ড বেছে নিন"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })
        setContentView(root)
    }
}
