package com.example.translatorkeyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.ExtractedTextRequest
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

class TranslatorKeyboardService : InputMethodService() {

    private val identifier = LanguageIdentification.getClient()
    private val prefs by lazy { getSharedPreferences("prefs", MODE_PRIVATE) }
    private val chips = mutableMapOf<String, Button>()
    private lateinit var status: TextView
    private var target = "en"

    private fun langName(code: String) =
        Locale(code).getDisplayLanguage(Locale("bn")).ifBlank { code }

    override fun onCreateInputView(): View {
        target = prefs.getString("target", "en") ?: "en"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF2F2F2.toInt())
            setPadding(16, 16, 16, 16)
        }
        status = TextView(this).apply {
            textSize = 14f
            text = "যে ভাষায় অনুবাদ চান সেটা বেছে \"অনুবাদ\" চাপুন"
        }
        root.addView(status)

        // ভাষার তালিকা (অনুভূমিকভাবে স্ক্রল হবে)
        val row = LinearLayout(this)
        TranslateLanguage.getAllLanguages().sortedBy { langName(it) }.forEach { code ->
            val b = Button(this).apply {
                isAllCaps = false
                text = langName(code)
                setOnClickListener { select(code) }
            }
            chips[code] = b
            row.addView(b)
        }
        root.addView(HorizontalScrollView(this).apply { addView(row) })
        select(target)

        // নিচের বাটন
        val actions = LinearLayout(this)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        actions.addView(Button(this).apply {
            text = "কিবোর্ড বদলান"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        }, lp)
        actions.addView(Button(this).apply {
            text = "অনুবাদ করুন"
            setOnClickListener { translateField() }
        }, lp)
        root.addView(actions)
        return root
    }

    private fun select(code: String) {
        target = code
        prefs.edit().putString("target", code).apply()
        chips.forEach { (c, b) -> b.alpha = if (c == code) 1f else 0.5f }
    }

    private fun readField(): String {
        val ic = currentInputConnection ?: return ""
        val full = ic.getExtractedText(ExtractedTextRequest(), 0)?.text?.toString()
        if (!full.isNullOrBlank()) return full.trim()
        val before = ic.getTextBeforeCursor(10000, 0) ?: ""
        val after = ic.getTextAfterCursor(10000, 0) ?: ""
        return (before.toString() + after.toString()).trim()
    }

    private fun translateField() {
        val text = readField()
        if (text.isEmpty()) { status.text = "চ্যাট বক্সে আগে কিছু লিখুন"; return }
        status.text = "অনুবাদ হচ্ছে..."

        identifier.identifyLanguage(text).addOnSuccessListener { detected ->
            val src = TranslateLanguage.fromLanguageTag(if (detected == "und") "en" else detected)
            if (src == null) { status.text = "এই ভাষা সমর্থিত নয়"; return@addOnSuccessListener }
            if (src == target) { status.text = "লেখাটি আগে থেকেই এই ভাষায়"; return@addOnSuccessListener }

            val translator = Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(target).build()
            )
            status.text = "প্রথমবার ভাষার ফাইল নামছে (ইন্টারনেট লাগবে)..."
            translator.downloadModelIfNeeded().addOnSuccessListener {
                translator.translate(text).addOnSuccessListener { out ->
                    currentInputConnection?.apply {
                        beginBatchEdit()
                        deleteSurroundingText(100000, 100000)
                        commitText(out, 1)
                        endBatchEdit()
                    }
                    status.text = "হয়ে গেছে ✓ (${langName(src)} → ${langName(target)})"
                    translator.close()
                }.addOnFailureListener { status.text = "অনুবাদ ব্যর্থ হয়েছে" }
            }.addOnFailureListener { status.text = "ডাউনলোড ব্যর্থ, ইন্টারনেট দেখুন" }
        }.addOnFailureListener { status.text = "ভাষা শনাক্ত করা যায়নি" }
    }
}
